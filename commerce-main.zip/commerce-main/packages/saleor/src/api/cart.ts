export default function () {}
