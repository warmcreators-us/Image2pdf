const commerce = require('./commerce.config.json')

module.exports = {
  commerce,
  images: {
    domains: ['cdn11.bigcommerce.com'],
  },
}
