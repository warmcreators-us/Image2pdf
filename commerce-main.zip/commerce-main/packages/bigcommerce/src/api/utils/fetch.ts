import vercelFetch from '@vercel/fetch'

export default vercelFetch()
