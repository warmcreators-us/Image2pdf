import * as Core from '@vercel/commerce/types/customer'

export * from '@vercel/commerce/types/customer'

export type CustomerSchema = Core.CustomerSchema
