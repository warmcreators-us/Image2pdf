export default function getCustomerWishlistOperation() {
  function getCustomerWishlist(): any {
    return { wishlist: {} }
  }
  return getCustomerWishlist
}
