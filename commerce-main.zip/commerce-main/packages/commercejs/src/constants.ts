export const CART_COOKIE = 'commercejs_cart_id'
export const CUSTOMER_COOKIE = 'commercejs_customer_token'
export const API_URL = 'https://api.chec.io/v1'
export const LOCALE = 'en-us'
